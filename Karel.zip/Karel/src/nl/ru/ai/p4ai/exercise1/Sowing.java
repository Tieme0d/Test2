package nl.ru.ai.p4ai.exercise1;

import static nl.ru.ai.karel.Karel.*;

public class Sowing
{

  public static void main(String[] args)
  {
    /* add your code for exercise 1.2 here */
  }

}
