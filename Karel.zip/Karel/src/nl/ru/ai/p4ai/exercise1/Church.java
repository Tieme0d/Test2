package nl.ru.ai.p4ai.exercise1;

import static nl.ru.ai.karel.Karel.*;

public class Church
{

  public static void main(String[] args)
  {
    map("church.map");
    /* Add your code for exercise 1.3 here */
  }

}
