package nl.ru.ai.p4ai.exercise1;

import static nl.ru.ai.karel.Karel.*;

public class House
{

  public static void main(String[] args)
  {
    /* Add your code for exercise 1.1 here */
  }

}
